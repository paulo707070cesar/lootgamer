<?php
return array (
  'db_host' => 'localhost',
  'db_name' => 'u940098558_lootgamer',
  'db_user' => 'u940098558_lootgamer',
  'db_pass' => 'X/uOIY7&g',
  'debug' => false,
);
